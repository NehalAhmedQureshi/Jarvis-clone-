# 🤖 Jarvis Android App — Setup Guide

## What This Does
- Wake word detection: say **"Hey Jarvis"** to activate hands-free
- **Open any app** by voice: "Open WhatsApp", "Open YouTube"
- **Make calls**: "Call Ali"
- **Send SMS**: "Text Ahmed I'm on my way"
- **Answer questions** using Claude AI: "What's the weather like in Karachi?"
- **Settings control**: "Open WiFi", "Open Bluetooth"

---

## Step 1 — Open in Android Studio
1. Download and install **Android Studio** from https://developer.android.com/studio
2. Open Android Studio → **File → Open** → select this `JarvisApp` folder
3. Wait for Gradle sync to finish (may take 2–5 minutes first time)

---

## Step 2 — Add Your API Keys

Open `app/build.gradle` and replace the placeholder keys:

```gradle
buildConfigField "String", "PICOVOICE_KEY", '"YOUR_PICOVOICE_KEY_HERE"'
buildConfigField "String", "CLAUDE_API_KEY", '"YOUR_CLAUDE_API_KEY_HERE"'
```

### Get Picovoice Key (Wake Word — FREE):
1. Go to https://console.picovoice.ai
2. Sign up for a free account
3. Copy your **AccessKey** from the dashboard
4. Paste it in place of `YOUR_PICOVOICE_KEY_HERE`

### Get Claude API Key (AI Answers):
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to **API Keys** → Create a new key
4. Paste it in place of `YOUR_CLAUDE_API_KEY_HERE`

> ⚠️ The app works WITHOUT keys too — you can tap the orb to activate manually, and local commands (open apps, calls, SMS, time/date) all work offline for free.

---

## Step 3 — Connect Your Phone & Run
1. On your Android phone: **Settings → Developer Options → Enable USB Debugging**
   - (To enable Developer Options: Settings → About Phone → tap Build Number 7 times)
2. Connect phone to computer with USB cable
3. In Android Studio, select your phone from the device dropdown at the top
4. Click the ▶ **Run** button (green triangle)
5. The app installs automatically on your phone!

---

## Step 4 — Grant Permissions
When the app opens, tap **Allow** for:
- Microphone (required for voice)
- Contacts (for calling/texting)
- Phone (for making calls)
- SMS (for sending messages)

---

## Voice Commands Reference

| Say this... | Jarvis does... |
|-------------|----------------|
| "Hey Jarvis" | Wakes up and listens |
| "Open WhatsApp" | Opens WhatsApp |
| "Open YouTube" | Opens YouTube |
| "Open settings" | Opens phone settings |
| "Open WiFi" | Opens WiFi settings |
| "Call Ali" | Calls Ali from contacts |
| "Text Ahmed I'll be late" | Sends SMS to Ahmed |
| "What time is it?" | Tells the time |
| "What day is it?" | Tells today's date |
| "What is the capital of France?" | Claude AI answers |
| "Tell me a joke" | Claude AI answers |

---

## Troubleshooting

**Wake word not working?**
- Make sure your Picovoice key is correct
- Check microphone permission is granted
- Go to Settings → Battery → find Jarvis → disable battery optimization

**"I couldn't find [app]" error?**
- Try a shorter name: "YouTube" instead of "YouTube Music"
- Some apps have different internal names

**Call/SMS not working?**
- Make sure CALL_PHONE and SEND_SMS permissions are granted in Settings → Apps → Jarvis → Permissions

**Claude not answering?**
- Check your internet connection
- Verify the Claude API key is correct
- Check if you have credits at console.anthropic.com

---

## Project Structure
```
JarvisApp/
├── app/build.gradle          ← Add your API keys here
├── app/src/main/
│   ├── AndroidManifest.xml   ← Permissions
│   ├── java/com/jarvis/app/
│   │   ├── MainActivity.kt       ← Main screen
│   │   ├── JarvisService.kt      ← Background wake word listener
│   │   ├── VoiceRecognizer.kt    ← Speech-to-text
│   │   ├── CommandProcessor.kt   ← Command brain/router
│   │   ├── AppController.kt      ← Opens apps
│   │   ├── PhoneController.kt    ← Calls & SMS
│   │   ├── AIController.kt       ← Claude API
│   │   ├── JarvisTTS.kt          ← Text-to-speech
│   │   ├── JarvisOrbView.kt      ← Animated orb UI
│   │   └── BootReceiver.kt       ← Auto-start on boot
│   └── res/
│       ├── layout/activity_main.xml ← UI layout
│       └── values/               ← Colors, strings, themes
```
