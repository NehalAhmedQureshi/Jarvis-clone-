package com.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIController {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val CLAUDE_KEY = BuildConfig.CLAUDE_API_KEY
    private val OPENAI_KEY = BuildConfig.OPENAI_API_KEY

    // ─── Change this to switch AI provider ───────────────
    // Options: "claude"  or  "chatgpt"
    private val ACTIVE_AI = "chatgpt"
    // ─────────────────────────────────────────────────────

    suspend fun askClaude(question: String): String = withContext(Dispatchers.IO) {
        return@withContext when (ACTIVE_AI) {
            "chatgpt" -> askChatGPT(question)
            else      -> askClaudeAPI(question)
        }
    }

    // ─── ChatGPT (OpenAI) ────────────────────────────────
    private suspend fun askChatGPT(question: String): String = withContext(Dispatchers.IO) {
        if (OPENAI_KEY == "YOUR_OPENAI_API_KEY_HERE" || OPENAI_KEY.isBlank()) {
            return@withContext "Please add your OpenAI API key in build.gradle."
        }

        return@withContext try {
            val requestBody = JSONObject().apply {
                put("model", "gpt-4o-mini")   // Fast & cheap. Change to "gpt-4o" for smarter answers
                put("max_tokens", 300)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", "You are Jarvis, a voice assistant on Android. " +
                            "Give VERY short answers — 1 to 2 sentences max. " +
                            "No markdown, no bullet points. Speak naturally.")
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", question)
                    })
                })
            }.toString()

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $OPENAI_KEY")
                .addHeader("Content-Type", "application/json")
                .post(requestBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return@withContext "No response from server."

            if (!response.isSuccessful) {
                return@withContext "OpenAI error ${response.code}. Check your API key."
            }

            JSONObject(responseBody)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()

        } catch (e: Exception) {
            "Sorry, I couldn't reach ChatGPT. Check your internet connection."
        }
    }

    // ─── Claude (Anthropic) ──────────────────────────────
    private suspend fun askClaudeAPI(question: String): String = withContext(Dispatchers.IO) {
        if (CLAUDE_KEY == "YOUR_CLAUDE_API_KEY_HERE" || CLAUDE_KEY.isBlank()) {
            return@withContext "Please add your Claude API key in build.gradle."
        }

        return@withContext try {
            val requestBody = JSONObject().apply {
                put("model", "claude-sonnet-4-20250514")
                put("max_tokens", 300)
                put("system", "You are Jarvis, a voice assistant on Android. " +
                    "Give VERY short answers — 1 to 2 sentences max. " +
                    "No markdown, no bullet points. Speak naturally.")
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", question)
                    })
                })
            }.toString()

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", CLAUDE_KEY)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(requestBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return@withContext "No response."

            if (!response.isSuccessful) {
                return@withContext "Claude error ${response.code}. Check your API key."
            }

            JSONObject(responseBody)
                .getJSONArray("content")
                .getJSONObject(0)
                .getString("text")
                .trim()

        } catch (e: Exception) {
            "Sorry, I couldn't reach Claude. Check your internet connection."
        }
    }
}
