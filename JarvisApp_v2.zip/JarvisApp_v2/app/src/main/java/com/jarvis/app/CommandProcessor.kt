package com.jarvis.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CommandProcessor(private val context: Context) {

    private val appController = AppController(context)
    private val phoneController = PhoneController(context)
    private val aiController = AIController()

    suspend fun process(command: String): String = withContext(Dispatchers.IO) {
        val lower = command.lowercase().trim()

        return@withContext when {

            // ─── Open app ───
            lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("start ") -> {
                val appName = lower
                    .removePrefix("open ").removePrefix("launch ").removePrefix("start ").trim()
                val success = appController.openApp(appName)
                if (success) "Opening $appName" else "Sorry, I couldn't find $appName on your phone."
            }

            // ─── Settings shortcuts ───
            lower.contains("wifi") || lower.contains("wi-fi") -> {
                appController.openWifi()
                "Opening WiFi settings"
            }

            lower.contains("bluetooth") -> {
                appController.openBluetooth()
                "Opening Bluetooth settings"
            }

            lower.contains("brightness") -> {
                appController.openDisplaySettings()
                "Opening display settings"
            }

            lower.contains("volume") -> {
                appController.openSoundSettings()
                "Opening sound settings"
            }

            // ─── Phone calls ───
            lower.startsWith("call ") -> {
                val name = lower.removePrefix("call ").trim()
                val result = phoneController.makeCall(name)
                result
            }

            // ─── SMS ───
            lower.startsWith("text ") || lower.startsWith("send message to ") || lower.startsWith("message ") -> {
                phoneController.handleSmsCommand(lower)
            }

            // ─── Time/Date (handled locally, no API needed) ───
            lower.contains("what time") || lower.contains("current time") -> {
                val time = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
                    .format(java.util.Date())
                "The time is $time"
            }

            lower.contains("what day") || lower.contains("what date") || lower.contains("today's date") -> {
                val date = java.text.SimpleDateFormat("EEEE, MMMM d, yyyy", java.util.Locale.getDefault())
                    .format(java.util.Date())
                "Today is $date"
            }

            // ─── Stop / cancel ───
            lower == "stop" || lower == "cancel" || lower == "never mind" -> {
                "Okay."
            }

            // ─── Fallback: ask Claude AI ───
            else -> {
                aiController.askClaude(command)
            }
        }
    }
}
