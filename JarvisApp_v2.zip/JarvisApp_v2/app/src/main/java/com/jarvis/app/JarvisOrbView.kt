package com.jarvis.app

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

class JarvisOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var pulseScale = 1f
    private var glowAlpha = 180
    private var ringRadius = 0f

    private var pulseAnimator: AnimatorSet? = null

    init {
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 4f
        ringPaint.color = Color.parseColor("#1E90FF")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (minOf(width, height) / 2f) * 0.45f

        // Glow layer
        glowPaint.shader = RadialGradient(
            cx, cy, radius * 1.8f * pulseScale,
            intArrayOf(
                Color.argb(glowAlpha, 30, 144, 255),
                Color.argb(40, 0, 100, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 2f * pulseScale, glowPaint)

        // Core orb
        corePaint.shader = RadialGradient(
            cx - radius * 0.3f, cy - radius * 0.3f, radius * 1.2f,
            intArrayOf(
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#60CFFF"),
                Color.parseColor("#1E90FF"),
                Color.parseColor("#003080")
            ),
            floatArrayOf(0f, 0.2f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * pulseScale, corePaint)

        // Pulsing ring
        if (ringRadius > 0) {
            ringPaint.alpha = (255 * (1f - ringRadius / (radius * 2.5f))).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, ringRadius, ringPaint)
        }
    }

    fun startPulse() {
        pulseAnimator?.cancel()

        val scaleAnim = ObjectAnimator.ofFloat(this, "pulseScale", 1f, 1.15f).apply {
            duration = 600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }

        val glowAnim = ObjectAnimator.ofInt(this, "glowAlpha", 180, 255).apply {
            duration = 600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
        }

        val cx = width / 2f
        val maxRing = minOf(width, height) / 2f
        val ringAnim = ObjectAnimator.ofFloat(this, "ringRadius", 0f, maxRing).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }

        pulseAnimator = AnimatorSet().apply {
            playTogether(scaleAnim, glowAnim, ringAnim)
            start()
        }
    }

    fun stopPulse() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        pulseScale = 1f
        glowAlpha = 180
        ringRadius = 0f
        invalidate()
    }

    // Property setters for ObjectAnimator
    fun setPulseScale(value: Float) { pulseScale = value; invalidate() }
    fun getPulseScale() = pulseScale
    fun setGlowAlpha(value: Int) { glowAlpha = value; invalidate() }
    fun getGlowAlpha() = glowAlpha
    fun setRingRadius(value: Float) { ringRadius = value; invalidate() }
    fun getRingRadius() = ringRadius
}
