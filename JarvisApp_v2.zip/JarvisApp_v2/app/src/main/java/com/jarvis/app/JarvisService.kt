package com.jarvis.app

import ai.picovoice.porcupine.*
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class JarvisService : Service(), PorcupineManagerCallback {

    private var porcupineManager: PorcupineManager? = null
    private val CHANNEL_ID = "jarvis_channel"
    private val NOTIF_ID = 1

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        startWakeWordDetection()
        return START_STICKY
    }

    private fun startWakeWordDetection() {
        try {
            val apiKey = BuildConfig.PICOVOICE_KEY

            if (apiKey == "YOUR_PICOVOICE_KEY_HERE" || apiKey.isBlank()) {
                // Key not set — service will still run, but wake word won't work
                // User must tap the orb manually instead
                return
            }

            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(apiKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(applicationContext, this)

            porcupineManager?.start()

        } catch (e: PorcupineInvalidArgumentException) {
            e.printStackTrace()
        } catch (e: PorcupineActivationException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ─── Called when "Hey Jarvis" is detected ───
    override fun invoke(keywordIndex: Int) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("WAKE_WORD_TRIGGERED", true)
        }
        startActivity(intent)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Jarvis Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Jarvis is listening for wake word"
            setShowBadge(false)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText("Listening for \"Hey Jarvis\"...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            porcupineManager?.stop()
            porcupineManager?.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
