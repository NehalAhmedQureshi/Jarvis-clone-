package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var voiceRecognizer: VoiceRecognizer
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var tts: JarvisTTS

    private val PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    )
    private val PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tts = JarvisTTS(this)
        voiceRecognizer = VoiceRecognizer(this)
        commandProcessor = CommandProcessor(this)

        setupUI()
        checkAndRequestPermissions()
    }

    private fun setupUI() {
        // Pulse animation on the Jarvis orb
        binding.orbView.setOnClickListener {
            activateListening()
        }

        binding.btnMic.setOnClickListener {
            activateListening()
        }

        setStatus("Say  \"Hey Jarvis\"  or tap the orb")
    }

    fun activateListening() {
        setStatus("Listening...")
        binding.orbView.startPulse()
        tts.speak("Yes?") {
            startVoiceListening()
        }
    }

    private fun startVoiceListening() {
        voiceRecognizer.onResult = { command ->
            runOnUiThread {
                binding.tvCommand.text = "\"$command\""
                setStatus("Processing...")
                binding.orbView.stopPulse()
            }
            lifecycleScope.launch {
                val reply = commandProcessor.process(command)
                runOnUiThread {
                    binding.tvReply.text = reply
                    setStatus("Say  \"Hey Jarvis\"  or tap the orb")
                }
                tts.speak(reply)
            }
        }
        voiceRecognizer.onError = {
            runOnUiThread {
                setStatus("Didn't catch that. Try again.")
                binding.orbView.stopPulse()
            }
        }
        voiceRecognizer.startListening()
    }

    private fun setStatus(text: String) {
        binding.tvStatus.text = text
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getBooleanExtra("WAKE_WORD_TRIGGERED", false) == true) {
            activateListening()
        }
    }

    private fun checkAndRequestPermissions() {
        val missing = PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_CODE)
        } else {
            startJarvisService()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_CODE) {
            startJarvisService()
        }
    }

    private fun startJarvisService() {
        val intent = Intent(this, JarvisService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
        voiceRecognizer.destroy()
    }
}
