package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager

class PhoneController(private val context: Context) {

    fun makeCall(contactName: String): String {
        val number = lookupContact(contactName)
        return if (number != null) {
            val callIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$number")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(callIntent)
            "Calling $contactName"
        } else {
            "I couldn't find $contactName in your contacts."
        }
    }

    fun handleSmsCommand(command: String): String {
        // Patterns supported:
        // "text Ali how are you"
        // "send message to Ali how are you"
        // "message Ali I'm on my way"

        val cleaned = command
            .removePrefix("send message to ")
            .removePrefix("text ")
            .removePrefix("message ")
            .trim()

        // First word = contact name, rest = message
        val spaceIndex = cleaned.indexOf(' ')
        if (spaceIndex == -1) {
            return "Please say: text [name] [your message]"
        }

        val name = cleaned.substring(0, spaceIndex)
        val message = cleaned.substring(spaceIndex + 1).trim()

        if (message.isEmpty()) {
            return "Please say a message after the name."
        }

        return sendSms(name, message)
    }

    private fun sendSms(contactName: String, message: String): String {
        val number = lookupContact(contactName)
        return if (number != null) {
            try {
                val smsManager = context.getSystemService(SmsManager::class.java)
                smsManager.sendTextMessage(number, null, message, null, null)
                "Message sent to $contactName"
            } catch (e: Exception) {
                "Failed to send message: ${e.message}"
            }
        } else {
            "I couldn't find $contactName in your contacts."
        }
    }

    private fun lookupContact(name: String): String? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )

        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, projection, null, null, null)
            cursor?.use {
                while (it.moveToNext()) {
                    val contactName = it.getString(1) ?: continue
                    val number = it.getString(0) ?: continue
                    if (contactName.lowercase().contains(name.lowercase())) {
                        return number
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }
}
