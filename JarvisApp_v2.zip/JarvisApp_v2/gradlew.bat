@rem Gradle startup script for Windows
@echo off
set GRADLE_VERSION=8.0
set GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin
set GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if not exist "%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
    mkdir "%GRADLE_HOME%"
    powershell -Command "Invoke-WebRequest '%GRADLE_URL%' -OutFile '%GRADLE_HOME%\gradle-%GRADLE_VERSION%-bin.zip'"
    powershell -Command "Expand-Archive '%GRADLE_HOME%\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_HOME%'"
)

"%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
